﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventarioApp_DAL
{
    public class ProductoRepository
    {
        private static List<Producto> productos = new List<Producto>();
        public void Agregar(Producto producto)
        {
            productos.Add(producto);
        }

        public List<Producto> ObtenerTodos()
        {
            return productos;
        }
    }

    public class Producto
    {
        public string Nombre { get; set; }
        public int Cantidad { get; set; }
    }
}
