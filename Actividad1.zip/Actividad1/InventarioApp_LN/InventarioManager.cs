﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InventarioApp_DAL;

namespace InventarioApp_BLL
{
    public class InventarioManager
    {
        private ProductoRepository _repo = new ProductoRepository();

        public void AgregarProducto(string nombre, int cantidad)
        {
            if (!string.IsNullOrWhiteSpace(nombre) && cantidad > 0)
            {
                _repo.Agregar(new Producto { Nombre = nombre, Cantidad = cantidad });
            }
        }

        public List<Producto> ListarProductos()
        {
            return _repo.ObtenerTodos();
        }
    }
}
